# US-21 Command Dequip

## Summary

Dequip the player from a weapon or protection, add it to his inventory, 
or drop it at the current location, if there is not enough inventory space.
Or if the item can not be put in the inventory.
  
## Main Success Scenario

Para
