# US-15 Command Backpack

## Summary

Shows the content of the players inventory.
  
## Main Success Scenario

Para
