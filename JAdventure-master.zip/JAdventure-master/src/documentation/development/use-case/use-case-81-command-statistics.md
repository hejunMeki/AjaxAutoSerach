# US-81 Command Statistics

## Summary

Show the player statistics.
  
## Main Success Scenario

Para
