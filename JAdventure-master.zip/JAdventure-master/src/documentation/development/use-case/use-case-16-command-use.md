# UC-12 Command Use

## Summary

Use an item, of type tool, like lock-and-pick, key to open a door.
  
## Main Success Scenario

Para
