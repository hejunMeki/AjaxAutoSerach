# US-20 Command Equip

## Summary

Equip the player with a weapon, from his inventory, or from the current location.
  
## Main Success Scenario

Para
