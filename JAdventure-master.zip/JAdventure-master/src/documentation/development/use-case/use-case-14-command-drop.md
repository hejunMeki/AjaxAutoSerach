# US-14 Command Drop

## Summary

Drop an item, at the current location. Which is then removed from the player inventory.
  
## Main Success Scenario

Para
