# US-13 Command Pick

## Summary

Pick up an item, from the current location. Which is then added to the player inventory.
  
## Main Success Scenario

Para
