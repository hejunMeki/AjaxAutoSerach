# UC-12 Command Inspect

## Summary

Inspect an item, to get extra information about it.
  
## Main Success Scenario

Para
