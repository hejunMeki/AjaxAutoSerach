# US-21 Command Attack

## Summary

Attack a Monster, to kill it.
  
**WARNING:**
  
Nothing is known about the attack / fight details yet. And what calculations are done.
  
## Main Success Scenario

Para
