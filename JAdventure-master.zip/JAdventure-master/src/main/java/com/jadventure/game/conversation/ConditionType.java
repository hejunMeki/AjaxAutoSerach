package com.jadventure.game.conversation;

public enum ConditionType {
    NONE,
    ALLY,
    ENEMY,
    LEVEL,
    ITEM,
    CHAR_TYPE
}
