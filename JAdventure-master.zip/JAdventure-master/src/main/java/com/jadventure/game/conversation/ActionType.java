package com.jadventure.game.conversation;

public enum ActionType {
    NONE,
    ATTACK,
    BUY,
    SELL,
    TRADE,
    GIVE,
    TAKE
}
